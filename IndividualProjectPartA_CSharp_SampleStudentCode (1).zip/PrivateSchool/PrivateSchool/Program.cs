﻿namespace PrivateSchool
{
    class Program
    {
        static void Main(string[] args)
        {
            PrivateSchool privateSchool = new PrivateSchool("AFDEmp");
            privateSchool.Run();
        }
    }
}
